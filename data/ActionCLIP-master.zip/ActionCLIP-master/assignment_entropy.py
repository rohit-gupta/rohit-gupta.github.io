import pickle
from glob import glob
import torch
import clip
import sys
import json
import numpy as np
from pprint import pprint

from multiprocessing import Pool
from itertools import groupby 
from scipy.special import entr

# action = sys.argv[1]
template = 'a demonstration of a person performing {0} while {1}.'
subaction_files = glob(f"/home/c3-0/rohitg/ActionCLIP/ActionCLIP/gpt/results/ucf101/direct_prompting_gpt3.5/*.json")


for subaction_file in subaction_files:
    action = subaction_file.split("/")[-1].split(".")[0]
    with open(subaction_file, "r") as f:
        subactions = json.load(f)

    subactions = [x[3:] for x in subactions['text'].split("\n")]
    # print(subactions)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/16", device=device)

    text = clip.tokenize([template.format(action.lower(), x.lower()) for x in subactions]).to(device)
    with torch.no_grad():
        text_features= model.encode_text(text)

    features_path = "/home/c3-0/globus/praveen/ActionCLIP/frame_features/ucf101_openvclip"
    feat_files = glob(f"{features_path}/*.pkl")
    feat_files = [x for x in feat_files if action.replace(" ","") in x]
    # print(feat_files[0])

    def load_feat(x):
        try:
            with open(x, "rb") as f:
                z = pickle.load(f)
        except:
            z = None
        return z


    def calc_edge_transitions(deduped_assignments):
        transitions = {}
        prev = deduped_assignments[0]
        for x in deduped_assignments:
            curr = f"{prev}_{x}"
            if curr in transitions.keys():
                transitions[curr] += 1
            else:
                transitions[curr] = 1

        return transitions


    with Pool(12) as p:
        feats = p.map(load_feat, feat_files)
    count_Nones = sum([1 for x in feats if x is None])
    if count_Nones > 0:
        print(f"[ERROR] {count_Nones=}")
    feats = [x for x in feats if x is not None]
    concat = []
    edge_counts = {}
    for feat in feats:
        if feat['label'] == action.replace(" ",""):
            similarity = (100.0 * torch.from_numpy(feat['features']).to(device="cuda:0", dtype=torch.float) @ text_features.to(device="cuda:0", dtype=torch.float).T) # softmax for sharpening ?
            #print(similarity.shape)
            # print(similarity[0])
            # print(similarity[0].sum())
            assignments = similarity.argmax(dim=-1).tolist()
            deduped_assignments = [i[0] for i in groupby(assignments)]
            trans_dict = calc_edge_transitions(deduped_assignments)
            for k,v in trans_dict.items():
                if k in edge_counts.keys():
                    edge_counts[k] += v
                else:
                    edge_counts[k] = v
            # print(deduped_assignments)
            concat += assignments

            # sys.exit(-1)

    #print(concat)
    unique, counts = np.unique(concat, return_counts=True)
    probs = counts/counts.sum()
    print(f"{action},{entr(probs).sum()}")


    # counts_dict = dict(zip(unique, counts))

    # for k,v in counts_dict.items():
        # print(subactions[k], v)

    # pprint(edge_counts)
