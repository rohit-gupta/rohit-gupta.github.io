import os
from class_names import ucf101, k400, multithumos, charades, hmdb51, coin
import json
import sys
import pathlib
from llms import LLM_NAMES, load_model_tokenizer, get_class_subactions, get_class_descriptors
import argparse

print(LLM_NAMES)


parser = argparse.ArgumentParser(description="Accept dataset name, prompting type, and an optional resume point.")
# Dataset name argument
parser.add_argument("-d", "--dataset", type=str, choices=['k400', 'ucf101', 'multithumos', 'hmdb51', 'charades', 'hmdb51', "coin"],
                    help="Name of the dataset. Choices: k400, ucf101, multithumos, hmdb51")
# Prompting type argument
parser.add_argument("-p", "--prompting", type=str, choices=['subaction', 'descriptor'], 
                    help="Type of prompting. Choices: subaction, descriptor")
# LLM argument
llm_names_string = ", ".join(LLM_NAMES)
parser.add_argument("-m", "--model", type=str, choices=LLM_NAMES, 
                    help=f"LLM to use. Choices: {llm_names_string}")
# Optional resume point argument
parser.add_argument("-r", "--resume", type=int, default=None, 
                    help="Optional integer representing the resume point.")

parser.add_argument("-q", "--quant", type=int, default=32, choices=[32,16,8,4],
                    help="Choose between 32, 16, 8 and 4 bit inference.")
args = parser.parse_args()


datasets = {'k400': k400, 'ucf101': ucf101, 'multithumos': multithumos, 'charades': charades, 'hmdb51': hmdb51, "coin": coin}
dataset = args.dataset
model_name = args.model

if args.prompting == "subaction":
  results_dir = f"results/{dataset}/subactions/{model_name}"
elif args.prompting == "descriptor":
  results_dir = f"results/{dataset}/descriptor/{model_name}"
p = pathlib.Path(f"{results_dir}/")
p.mkdir(parents=True, exist_ok=True)


model, tokenizer = load_model_tokenizer(model_name, args.quant)

if args.resume is not None:
  resume_point = args.resume
else:
  resume_point = 0


for idx, class_name in enumerate(datasets[dataset][resume_point:]):

  if args.prompting == "subaction":
    prompt, result = get_class_subactions(model_name, model, tokenizer, class_name)
  elif args.prompting == "descriptor":
    prompt, result = get_class_descriptors(model_name, model, tokenizer, class_name)


  with open(f"{results_dir}/{class_name}.json", "w") as f:
    response = {}
    response['dataset'] = dataset
    response['class_name'] = class_name
    response['text'] = result
    response['llm'] = model_name
    response['prompt'] = prompt
    result_json = json.dumps(response, indent=1)
    print(result_json, file=f)
    print(f"[{dataset}] [{idx+resume_point}/{len(datasets[dataset])}] <{class_name}> Done", flush=True)
