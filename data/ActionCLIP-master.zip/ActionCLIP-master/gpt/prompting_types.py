import os
import openai

openai.api_key = os.getenv("OPENAI_API_KEY")



def subaction_direct(class_name, model_name="gpt-3.5-turbo-0613"):

  response = openai.ChatCompletion.create(
      model=model_name,
      messages=[
        {
          "role": "system",
          "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos"
        },
        {
          "role": "user",
          "content": f"Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing {class_name}:\n"
        }
      ],
      temperature=0.5,
      max_tokens=256,
      top_p=0.6,
      frequency_penalty=0,
      presence_penalty=0
    )
  return response



def descriptor_direct(class_name, model_name="gpt-3.5-turbo-0613"):

  response = openai.ChatCompletion.create(
    model=model_name,
    messages=[
      {
        "role": "system",
        "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos"
      },
      {
        "role": "user",
        "content": f"Q: What does a video of a {class_name} look like visually ? Use few words in each bullet point \n\nA: Here is a list of ten visual features to recognize there is {class_name} in a video:"
      }
    ],
    temperature=0.4,
    max_tokens=1024,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0
  )

  return response



def noun_direct(class_name, model_name="gpt-3.5-turbo-0613"):

  response = openai.ChatCompletion.create(
    model=model_name,
    messages=[
      {
        "role": "system",
        "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos"
      },
      {
        "role": "user",
        "content": f"Return a numbered list of just the noun for the specific objects a person would use while doing {class_name}"
      }
    ],
    temperature=0.4,
    max_tokens=1024,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0
  )

  return response



def adverb_direct(class_name, model_name="gpt-3.5-turbo-0613"):

  response = openai.ChatCompletion.create(
    model=model_name,
    messages=[
      {
        "role": "system",
        "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos"
      },
      {
        "role": "user",
        "content": f"Return a numbered list of just the the adverbs for the specific actions a person would perform while doing {class_name}"
      }
    ],
    temperature=0.4,
    max_tokens=1024,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0
  )

  return response


def verb_direct(class_name, model_name="gpt-3.5-turbo-0613"):

  response = openai.ChatCompletion.create(
      model=model_name,
      messages=[
        {
          "role": "system",
          "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos"
        },
        {
          "role": "user",
          "content": f"Return a numbered list of just the verb for the specific action steps a person would perform while doing {class_name}"
        }
      ],
      temperature=0.5,
      max_tokens=256,
      top_p=0.6,
      frequency_penalty=0,
      presence_penalty=0
    )
  return response



