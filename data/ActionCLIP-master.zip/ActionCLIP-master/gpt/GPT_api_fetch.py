import os
import openai
from class_names import (
    ucf101,
    k400,
    multithumos,
    charades,
    hmdb51,
    hmdb51_con,
    coin,
    activitynet,
    k600,
    youcook2,
    youcook2_done,
    breakfast,
    rareact
)

from ht100m import ht100m_sports, ht100m_fitness
import json
import sys
import pathlib
from prompting_types import subaction_direct, descriptor_direct, noun_direct, adverb_direct, verb_direct
from utils import extract_list 
import argparse

openai.api_key = os.getenv("OPENAI_API_KEY")

parser = argparse.ArgumentParser(
    description="Accept dataset name, prompting type, and an optional resume point."
)
# Dataset name argument
parser.add_argument(
    "-d",
    "--dataset",
    type=str,
    choices=[
        "k400",
        "ucf101",
        "multithumos",
        "hmdb51",
        "charades",
        "hmdb51",
        "hmdb51_con",
        "coin",
        "activitynet",
        "k600",
        "youcook2",
        "breakfast",
        "ht100m_sports",
        "ht100m_fitness",
        "rareact"
    ],
    help="Name of the dataset. Choices: k400, ucf101, multithumos, hmdb51, hmdb51_con, coin, activitynet, k600, youcook2, breakfast, rareact",
)
# Prompting type argument
parser.add_argument(
    "-p",
    "--prompting",
    type=str,
    choices=["subaction", "descriptor", "noun", "adverb", "verb"],
    help="Type of prompting. Choices: subaction, descriptor",
)


gpts = ["gpt-4", "gpt-3.5-turbo-0613", "gpt-3.5-turbo-0301", "gpt-4-0314", "gpt-4-0613", "gpt-4-1106-preview", "gpt-3.5-turbo-1106"]
gpt_names = ",".join(gpts)
parser.add_argument(
    "-v",
    "--version",
    type=str,
    default="gpt-3.5-turbo-0613",
    choices=gpts,
    help=f"Type of GPT. Choices: {gpt_names}",
)

# Optional resume point argument
parser.add_argument(
    "-r",
    "--resume",
    type=int,
    default=None,
    help="Optional integer representing the resume point.",
)
args = parser.parse_args()

datasets = {
    "k400": k400,
    "ucf101": ucf101,
    "multithumos": multithumos,
    "charades": charades,
    "hmdb51": hmdb51,
    "hmdb51_con": hmdb51_con,
    "coin": coin,
    "activitynet": activitynet,
    "k600": k600,
    "youcook2": youcook2,
    "breakfast": breakfast,
    "ht100m_sports": ht100m_sports,
    "ht100m_fitness": ht100m_fitness,
    "rareact": rareact
}
dataset = args.dataset

results_dir = f"results/{dataset}/{args.version}/{args.prompting}_gpt3.5"
p = pathlib.Path(f"{results_dir}/")
p.mkdir(parents=True, exist_ok=True)

if args.resume is not None:
    resume_point = args.resume
else:
    resume_point = 0

for idx, class_name in enumerate(datasets[dataset][resume_point:]):

    if args.prompting == "subaction":
        response = subaction_direct(class_name, args.version)
    elif args.prompting == "descriptor":
        response = descriptor_direct(class_name, args.version)
    elif args.prompting == "noun":
        response = noun_direct(class_name, args.version)
    elif args.prompting == "adverb":
        response = adverb_direct(class_name, args.version)
    elif args.prompting == "verb":
        response = verb_direct(class_name, args.version)

    with open(f"{results_dir}/{class_name}.json", "w") as f:
        result = {}
        result["dataset"] = dataset
        result["class_name"] = class_name
        result["text"] = response["choices"][0]["message"]["content"]
        result[f"{args.prompting}"] = extract_list(result['text'])
        result["finish_reason"] = response["choices"][0]["finish_reason"]
        result["total_tokens"] = response["usage"]["total_tokens"]
        result_json = json.dumps(result, indent=1)
        print(result_json, file=f)
        print(
            f"[{dataset}] [{idx + resume_point}/{len(datasets[dataset])}] <{class_name}> Done"
        )
