
from glob import glob
import json
from pprint import pprint
import pathlib
import re

#prompt_type = "descriptor"
prompt_type = "subactions"

test_files = [x.split("/")[-1] for x in glob(f"results/ucf101/{prompt_type}/vicuna-7b-v1.3/*.json")]

#test_files = ["Apply Eye Makeup.json"]

models = sorted(glob(f"results/ucf101/{prompt_type}/*"))
cleaned_models = [x.strip().split("/")[-1] for x in glob(f"results/ucf101/cleaned_{prompt_type}/*")]

for test_file in test_files:
	for model in models:
		# if all actions haven't been processed for a model skip it
		if len(glob(f"{model}/*")) < 101:
			print(f"[{model}] skipped (extraction not finished)")
			continue 
		model_name = model.split("/")[-1]
		if model_name in cleaned_models:
			print(f"[{model}] skipped (already cleaned)")
			continue
		results_dir = f"results/ucf101/cleaned_{prompt_type}/{model_name}"
		p = pathlib.Path(f"{results_dir}/")
		p.mkdir(parents=True, exist_ok=True)
		
		with open(f"{model}/{test_file}", "r") as f:
			x = json.load(f)
		text, prompt = x["text"], x["prompt"]
		#print(model_name, text)
		prompt = prompt.replace("<s>", "").replace("</s>", "")
		text = text.replace("<s>", "").replace("</s>", "")
		text = re.sub(r'\n+', '\n', text).strip()
		for idx in range(100):
			if text.count(str(idx)) > 1:
				text = text.replace(f"#{str(idx)}:", "")
		text = text.replace("# of", "Number of").replace("#", "")
		for idx in range(100):
			text = text.replace(f"{str(idx)}:", f"{str(idx)}.")
		#print(model_name, text)

		end = prompt.find("1.")
		if end != -1:
			post_bullet = prompt[end+2:]
			prompt = prompt[:end]

		text = text.replace("1.\n", "\n1.")
		if end!=-1:
			text.replace(post_bullet, "")
		
		text = text.replace(prompt, "")
		text = text.strip()
		subactions = text.split("\n")
		count = 1
		filt_subactions = []
		for idx, y in enumerate(subactions):
			sel = False
			y = y.strip()
			if len(y) < 5:
				continue
			count_str = str(count)
			if y[:len(count_str)+1] == f"{count_str}.":
				sel = True
			elif y[:2] == f"- ":
				y = y.replace("- ", f"{count_str}. ")
				sel = True
			if sel:
				count += 1
				y = y.replace("The user is", "").replace("The user has", "")
				y = y.replace("  ", " ").replace("  ", " ")
				filt_subactions.append(y)
		x[f"{prompt_type}"] = filt_subactions
		#print(model_name, filt_subactions)
		#if len(filt_subactions) < 3:
		#	print("ERROR")
		with open(f"{results_dir}/{test_file}", "w") as f:
			result_json = json.dumps(x, indent=1)
			print(result_json, file=f)
		

		#print(f"[{model}]")
		#pprint(filt_subactions)
		


