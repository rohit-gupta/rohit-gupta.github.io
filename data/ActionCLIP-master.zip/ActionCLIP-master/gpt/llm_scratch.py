


# Load model directly
from transformers import AutoTokenizer, AutoModelForCausalLM


#model_name = "lmsys/vicuna-13b-v1.5" 
#model_name = "lmsys/vicuna-7b-v1.5" 
#model_name = "meta-llama/Llama-2-70b-chat-hf" 


base_path = "/home/rgupta/llama/"
model_path = f"{base_path}/weights_tulu/tulu-65b/"
#model_path = f"{base_path}/weights_hf/llama-7b/"

tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True)


#tokenizer = AutoTokenizer.from_pretrained(model_name)
#model = AutoModelForCausalLM.from_pretrained(model_name)

class_name = "Cricket Bowling"
#prompt = f"You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos. Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing {class_name}:\n"


# Vicuna Prompt 
# https://github.com/lm-sys/FastChat/blob/main/docs/vicuna_weights_version.md#prompt-template

# TULU Prompt
prompt = f"""<|user|>
You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos. Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing {class_name}
<|assistant|>
"""

# Llama 1 prompt
#prompt = f"""You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos. Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing {class_name}.
#1."""

# Llama2-Chat Prompt
#prompt = [
#  {"role": "system", "content": "You are helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos."},
#  {"role": "user", "content": f"Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing {class_name}"},
#]

#tokenizer.use_default_system_prompt = False
#prompt = tokenizer.apply_chat_template(prompt, tokenize=False)
inputs = tokenizer(prompt, return_tensors="pt")


#generate_ids = model.generate(inputs.input_ids, do_sample=True, temperature=0.4, max_new_tokens=1024)
generate_ids = model.generate(inputs.input_ids, do_sample=False, max_new_tokens=1024, no_repeat_ngram_size=5)
result = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
print(result)
