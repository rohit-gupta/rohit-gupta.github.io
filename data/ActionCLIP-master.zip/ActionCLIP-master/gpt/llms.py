
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM



VICUNA_MODELS = ["lmsys/vicuna-7b-v1.3", "lmsys/vicuna-13b-v1.3", "lmsys/vicuna-33b-v1.3", "lmsys/vicuna-7b-v1.5", "lmsys/vicuna-13b-v1.5"]
TULU_MODELS = ["tulu-7b", "tulu-13b", "tulu-30b", "tulu-65b"]
LLAMA1_MODELS = ["llama-7b", "llama-13b", "llama-30b", "llama-65b"]
LLAMA2_MODELS = ["meta-llama/Llama-2-7b-hf", "meta-llama/Llama-2-13b-hf", "meta-llama/Llama-2-70b-hf"]
LLAMA2CHAT_MODELS = ["meta-llama/Llama-2-7b-chat-hf", "meta-llama/Llama-2-13b-chat-hf", "meta-llama/Llama-2-70b-chat-hf"]
MISTRAL_MODELS = ["Open-Orca/Mistral-7B-OpenOrca", "HuggingFaceH4/zephyr-7b-alpha"]


AVAIL_LLMS = {x.split("/")[-1].lower() : x for x in  VICUNA_MODELS + LLAMA2_MODELS + LLAMA2CHAT_MODELS + MISTRAL_MODELS + LLAMA1_MODELS + TULU_MODELS}
LLM_NAMES = list(AVAIL_LLMS.keys())

def load_model_tokenizer(model_name, quant=32):
  model_name = AVAIL_LLMS[model_name]
  if model_name in VICUNA_MODELS + LLAMA2_MODELS + LLAMA2CHAT_MODELS + MISTRAL_MODELS:
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if quant == 32:
      model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto")
    elif quant == 16:
      model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", torch_dtype=torch.bfloat16, use_flash_attention_2=True)
    elif quant == 8:
      model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", load_in_8bit=True, use_flash_attention_2=True)
    elif quant == 4:
      model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", load_in_4bit=True, use_flash_attention_2=True)
  elif model_name in LLAMA1_MODELS + TULU_MODELS:
    base_path = "/home/rgupta/llama/"

    if model_name in TULU_MODELS:
      model_path = f"{base_path}/weights_tulu/{model_name}/"
    elif model_name in LLAMA1_MODELS:
      model_path = f"{base_path}/weights_hf/{model_name}/"

    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    if quant == 32:
      model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, device_map="auto")
    elif quant == 16:
      model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, device_map="auto", torch_dtype=torch.bfloat16, use_flash_attention_2=True)
    elif quant == 8:
      model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, device_map="auto", load_in_8bit=True, use_flash_attention_2=True)
    elif quant == 4:
      model = AutoModelForCausalLM.from_pretrained(model_path, local_files_only=True, device_map="auto", load_in_4bit=True, use_flash_attention_2=True)
  return model, tokenizer


def get_class_subactions(model_name, model, tokenizer, class_name):
  model_name = AVAIL_LLMS[model_name]

  ACTIONREC_SYSTEM_PROMPT = "The assistant is helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos."
  SUBACTION_PROMPT = "Return a numbered list of just the verb phrase for the specific action steps a person would perform while doing"

  if model_name in VICUNA_MODELS:
    prompt = f"""A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions. {ACTIONREC_SYSTEM_PROMPT}
        USER: {SUBACTION_PROMPT} {class_name}
        ASSISTANT: """

  if model_name in TULU_MODELS:
    prompt = f"""<|user|>
        {ACTIONREC_SYSTEM_PROMPT} {SUBACTION_PROMPT} {class_name}
        <|assistant|>
        """

  if model_name in LLAMA1_MODELS + LLAMA2_MODELS:
    prompt = f"""{ACTIONREC_SYSTEM_PROMPT} {SUBACTION_PROMPT} {class_name}.\n1."""

  if model_name in LLAMA2CHAT_MODELS:
    prompt = [
      {"role": "system", "content": ACTIONREC_SYSTEM_PROMPT},
      {"role": "user", "content": f"{SUBACTION_PROMPT} {class_name}"},
    ]
    tokenizer.use_default_system_prompt = False
    prompt = tokenizer.apply_chat_template(prompt, tokenize=False)

  if model_name in MISTRAL_MODELS:
    prompt = [
      {"role": "system", "content": ACTIONREC_SYSTEM_PROMPT},
      {"role": "user", "content": f"{SUBACTION_PROMPT} {class_name}"},
    ]
    prompt = tokenizer.apply_chat_template(prompt, tokenize=False, add_generation_prompt=True)


  inputs = tokenizer(prompt, return_tensors="pt")
  input_tokens = inputs.input_ids.to('cuda')
  generate_ids = model.generate(input_tokens, do_sample=False, max_new_tokens=1024, no_repeat_ngram_size=5)
  result = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
  return prompt, result


def get_class_descriptors(model_name, model, tokenizer, class_name):

  model_name = AVAIL_LLMS[model_name]

  ACTIONREC_SYSTEM_PROMPT = "The assistant is helpfully assisting the user in understanding human actions for the purpose of visually recognizing them in videos."
  DESCRIPTOR_QUESTION = f"What does a video of a {class_name} look like visually ? Use few words in each bullet point"
  DESCRIPTOR_ANSWER = f"Here is a list of ten visual features to recognize there is {class_name} in a video:"


  if model_name in VICUNA_MODELS:
    prompt = f"A chat between a curious user and an artificial intelligence assistant. The assistant gives helpful, detailed, and polite answers to the user's questions. {ACTIONREC_SYSTEM_PROMPT}\nUSER: {DESCRIPTOR_QUESTION}\nASSISTANT: {DESCRIPTOR_ANSWER}\n1."

  if model_name in TULU_MODELS:
    prompt = f"<|user|>\n{ACTIONREC_SYSTEM_PROMPT} {DESCRIPTOR_QUESTION}\n<|assistant|>\n{DESCRIPTOR_ANSWER}\n1."

  if model_name in LLAMA1_MODELS + LLAMA2_MODELS:
    prompt = f"{ACTIONREC_SYSTEM_PROMPT} {SUBACTION_PROMPT} {class_name}.\n1."

  if model_name in LLAMA2CHAT_MODELS:
    prompt = [
      {"role": "system", "content": ACTIONREC_SYSTEM_PROMPT},
      {"role": "user", "content": f"{DESCRIPTOR_QUESTION}"},
      {"role": "assistant", "content": f"{DESCRIPTOR_ANSWER}\n1."},
    ]
    tokenizer.use_default_system_prompt = False
    prompt = tokenizer.apply_chat_template(prompt, tokenize=False)

  if model_name in MISTRAL_MODELS:
    prompt = [
      {"role": "system", "content": ACTIONREC_SYSTEM_PROMPT},
      {"role": "user", "content": f"{DESCRIPTOR_QUESTION}"},
      {"role": "assistant", "content": f"{DESCRIPTOR_ANSWER}\n1."},
    ]
    prompt = tokenizer.apply_chat_template(prompt, tokenize=False, add_generation_prompt=False)


  inputs = tokenizer(prompt, return_tensors="pt")
  input_tokens = inputs.input_ids.to('cuda')
  generate_ids = model.generate(input_tokens, do_sample=False, max_new_tokens=1024, no_repeat_ngram_size=5)
  result = tokenizer.batch_decode(generate_ids, skip_special_tokens=True, clean_up_tokenization_spaces=False)[0]
  return prompt, result

