import pickle
from glob import glob
import torch
import clip
import sys
import json
import numpy as np
from pprint import pprint

from multiprocessing import Pool
from itertools import groupby 


action = sys.argv[1]
template = 'a demonstration of a person performing {0} while {1}.'


with open(f"/home/c3-0/rohitg/ActionCLIP/ActionCLIP/gpt/results/ucf101/direct_prompting_gpt3.5/{action}.json", "r") as f:
    subactions = json.load(f)

subactions = [x[3:] for x in subactions['text'].split("\n")]
print(subactions)


# subactions = {
#     "gpt4": ["Start with a running approach",
#              "Plant one foot on the takeoff board",
#              "Propel the body forward by extending the planted foot",
#              "Swing the arms forward and upward for momentum",
#              "Drive the opposite knee up towards the chest",
#              "Extend the driving leg forward",
#              "Extend the arms forward and upward for balance",
#              "Maintain a forward lean throughout the jump",
#              "Extend the legs forward for maximum distance",
#              "Land on the sand pit with both feet together"],
#     "tulu65b": [
#         "Run towards the takeoff board",
#         "Jump off the ground",
#         "Extend legs and arms to gain distance",
#         "Land on the sand pit"
#     ],
#     "gpt3.5": ["Start running towards the takeoff board",
#                "Build up speed and momentum",
#                "Plant the takeoff foot on the board",
#                "Propel the body forward using the takeoff foot",
#                "Extend the arms forward for balance",
#                "Swing the non-takeoff leg forward",
#                "Bring the non-takeoff leg forward and upward",
#                "Extend the body horizontally in mid-air",
#                "Prepare for landing by flexing the legs",
#                "Land on the sandpit with the feet first",
#                "Maintain balance and stability upon landing"],
#     "mistral7b": [
#         "Approach the takeoff board",
#         "Plant the lead foot",
#         "Lean forward",
#         "Push off the lead foot",
#         "Drive the trail leg",
#         "Extend the lead leg",
#         "Swing the trail leg",
#         "Land on the ball of the lead foot",
#         "Push off with the lead foot",
#         "Land on the mat",
#         "Extend the trail leg",
#         "Pause and measure the jump"
#     ]
#
# }

device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/16", device=device)

text = clip.tokenize([template.format(action.lower(), x.lower()) for x in subactions]).to(device)
with torch.no_grad():
    text_features= model.encode_text(text)

features_path = "/home/c3-0/globus/praveen/ActionCLIP/frame_features/ucf101_openvclip"
feat_files = glob(f"{features_path}/*.pkl")
feat_files = [x for x in feat_files if action.replace(" ","") in x]
print(feat_files[0])

def load_feat(x):
    try:
        with open(x, "rb") as f:
            z = pickle.load(f)
    except:
        z = None
    return z


def calc_edge_transitions(deduped_assignments):
    transitions = {}
    prev = deduped_assignments[0]
    for x in deduped_assignments:
        curr = f"{prev}_{x}"
        if curr in transitions.keys():
            transitions[curr] += 1
        else:
            transitions[curr] = 1

    return transitions


with Pool(8) as p:
    feats = p.map(load_feat, feat_files)
count_Nones = sum([1 for x in feats if x is None])
print(f"{count_Nones=}")
feats = [x for x in feats if x is not None]
concat = []
edge_counts = {}
for feat in feats:
    if feat['label'] == action.replace(" ",""):
        similarity = (100.0 * torch.from_numpy(feat['features']).to(device="cuda:0", dtype=torch.float) @ text_features.to(device="cuda:0", dtype=torch.float).T) # softmax for sharpening ?
        #print(similarity.shape)
        # print(similarity[0])
        # print(similarity[0].sum())
        assignments = similarity.argmax(dim=-1).tolist()
        deduped_assignments = [i[0] for i in groupby(assignments)]
        trans_dict = calc_edge_transitions(deduped_assignments)
        for k,v in trans_dict.items():
            if k in edge_counts.keys():
                edge_counts[k] += v
            else:
                edge_counts[k] = v
        print(deduped_assignments)
        concat += assignments

        # sys.exit(-1)

#print(concat)
unique, counts = np.unique(concat, return_counts=True)
counts_dict = dict(zip(unique, counts))

for k,v in counts_dict.items():
    print(subactions[k], v)

pprint(edge_counts)
