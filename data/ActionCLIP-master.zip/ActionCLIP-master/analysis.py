import matplotlib
import matplotlib.pyplot as plt
import json
import os
import numpy as np
import seaborn as sns
import pandas as pd
from transformers import AutoProcessor, CLIPVisionModelWithProjection
from transformers import AutoTokenizer, CLIPTextModelWithProjection
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import average_precision_score
import torch
import numpy as np
import os
from PIL import Image
import json
import pickle   
from tqdm import tqdm       
import decord 
decord.bridge.set_bridge('torch')
from decord import VideoReader
import cv2
import time
import matplotlib.pyplot as plt
from scipy.special import softmax
import random
from torchvision.transforms import Compose, Resize, CenterCrop, Normalize, Lambda
from torchvision.transforms import InterpolationMode 


def plot_subaction_distribution(datasets):
    data = {}
    for dataset in datasets:
        labels_folder = f"./data/direct_prompting_gpt3.5/{dataset}"
        num_subactions_list = []
        for f in os.listdir(labels_folder):
            class_label = f.replace('.json', '')
            output = json.load(open(os.path.join(labels_folder, f), 'r'))
            if 'text' in output.keys():
                sub_action_texts = output['text'].split('\n')
            else:
                sub_action_texts = output['subactions']
            num_subactions = len(sub_action_texts)
            num_subactions_list.append(num_subactions)
    
            data[dataset] = np.array(num_subactions_list, dtype=float)

    maxsize = max([len(a) for a in data.values()])
    data_pad = {k:np.pad(v, pad_width=(0, maxsize-len(v), ), mode='constant', constant_values=np.nan) for k,v in data.items()}
    df = pd.DataFrame(data_pad)
    
    sns.set(rc={'figure.figsize':(15, 5)})
    sns.set(font_scale=1.5)
    plt.rcParams["font.weight"] = "bold"
    ax = sns.violinplot(data=df)
    sns.boxplot(data=df, palette='turbo', width=0.3, boxprops={'zorder': 2}, ax=ax)
    plt.tight_layout()
    #plt.hist(num_subactions_list, bins=10)
    #plt.xlabel("Number fo sub-actions")
    #plt.ylabel("Number of action classes")
    plt.savefig("subaction_distributions.png", dpi=400)



def extract_label_features(model_string, labels_folder, mode=0, text_type='subaction', num_sub_actions=0):
    
    templates = [
        'a video of the person doing {}.',
        'a photo of a person {}.',
        'a video of a person {}.',
        'a example of a person {}.',
        'a demonstration of a person {}.',
        'a photo of the person {}.',
        'a video of the person {}.',
        'a example of the person {}.',
        'a demonstration of the person {}.',
        'a photo of a person using {}.',
        'a video of a person using {}.',
        'a example of a person using {}.',
        'a demonstration of a person using {}.',
        'a photo of the person using {}.',
        'a video of the person using {}.',
        'a example of the person using {}.',
        'a demonstration of the person using {}.',
        'a photo of a person doing {}.',
        'a video of a person doing {}.',
        'a example of a person doing {}.',
        'a demonstration of a person doing {}.',
        'a photo of the person doing {}.',
        'a example of the person doing {}.',
        'a demonstration of the person doing {}.',
        'a photo of a person during {}.',
        'a video of a person during {}.',
        'a example of a person during {}.',
        'a demonstration of a person during {}.',
        'a photo of the person during {}.',
        'a video of the person during {}.',
        'a example of the person during {}.',
        'a demonstration of the person during {}.',
        'a photo of a person performing {}.',
        'a video of a person performing {}.',
        'a example of a person performing {}.',
        'a demonstration of a person performing {}.',
        'a photo of the person performing {}.',
        'a video of the person performing {}.',
        'a example of the person performing {}.',
        'a demonstration of the person performing {}.',
        'a photo of a person practicing {}.',
        'a video of a person practicing {}.',
        'a example of a person practicing {}.',
        'a demonstration of a person practicing {}.',
        'a photo of the person practicing {}.',
        'a video of the person practicing {}.',
        'a example of the person practicing {}.',
        'a demonstration of the person practicing {}.',
    ]
    
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    model = CLIPTextModelWithProjection.from_pretrained(model_string)
    tokenizer = AutoTokenizer.from_pretrained(model_string)

    model.to(device)

    out = {}
    sub_texts = {}
    for f in os.listdir(labels_folder):
        class_label = f.replace('.json', '')
        output = json.load(open(os.path.join(labels_folder, f), 'r'))
        if 'text' in output.keys():
            sub_action_texts = output['text'].split('\n')
        else:
            sub_action_texts = output['subactions']
        if class_label not in sub_texts:
            sub_texts[class_label] = []
        sub_texts[class_label].extend(sub_action_texts)
    
    for class_label in sub_texts.keys():
        sub_action_texts = sub_texts[class_label]
        if mode == 0:
            inputs = [template.format(class_label) for template in templates]
            input_tokens = tokenizer(inputs, padding=True, return_tensors="pt", max_length=77).to(device)

            with torch.no_grad():
                outputs = model(**input_tokens)
            features = outputs.text_embeds
            
            key = class_label.replace(' ', '')
            if key not in out:
                out[key] = {}
            out[key]['features'] = features.cpu().detach().numpy()[:, None]
            out[key]['texts'] = inputs
        else:
            _templates = [templates[i] for i in [35, 27, 9]]
            for template in _templates: #templates[:1]:
                input_string = template.format(class_label)[:-1]
                if text_type == 'subaction':
                    inputs = [input_string + f" while {text[3:]}" for text in sub_action_texts]
                    #inputs = [text[3:] for text in sub_action_texts]
                    #inputs = [class_label + f" while {text[3:]}" for text in sub_action_texts]
                else:
                    inputs = [input_string + f" with {text[3:]}" for text in sub_action_texts]
                input_tokens = tokenizer(inputs, padding="max_length", return_tensors="pt", max_length=77, truncation=True).to(device)

                with torch.no_grad():
                    outputs = model(**input_tokens)
                features = outputs.text_embeds
                if num_sub_actions > 0:
                    features = sub_sample(features, num_sub_actions)

                key = class_label.replace(' ', '')
                if key not in out:
                    out[key] = {}
                    out[key]['features'] = []
                    out[key]['texts'] = []
                out[key]['features'].append(features.cpu().detach().numpy())
                out[key]['texts'].append(inputs)
    return out


def visualize_subaction_assignment(action_class, frame_features_folder, label_features, test_videos, num_frames=32, temperature=0):
    class_labels = sorted(list(label_features.keys()))
    
    assert action_class in class_labels
    text_features = label_features[action_class]['features']
    text_features = np.array(text_features).mean(axis=0)
    text_features = torch.from_numpy(text_features)

    counts = np.zeros(len(text_features))
    
    for video in tqdm(test_videos):
        video_id = video.split('/')[1].replace('.avi', '').replace('.mp4', '')
        if os.path.exists(os.path.join(frame_features_folder, video_id + '.pkl')):
            video_features = pickle.load(open(os.path.join(frame_features_folder, video_id + '.pkl'), 'rb'))
        else:   
            print(f"Missing video {video_id}")
            continue
        frame_features =  video_features['frame_features']
        frame_features = torch.from_numpy(frame_features)
        if num_frames > 0:
            frame_indicies = np.linspace(0, len(frame_features) - 1, num_frames).astype(int)
            frame_features = frame_features[frame_indicies]
        
        video_label = video_features['label'].replace('_', '')
        if video_label != action_class:
            continue
        
        assert video_label.lower() in [label.lower().replace('(', '').replace(')', '').replace('\'', '') for label in class_labels], (video_label, class_labels)
        
        frame_features /= frame_features.norm(dim=-1, keepdim=True)
        text_features /= text_features.norm(dim=-1, keepdim=True)
            
        sim_matrx = (frame_features.cuda() @ text_features.T.cuda()).cpu().data.numpy()

        for index in np.argmax(sim_matrx, axis=1):
            counts[index] += 1
    
    counts = counts/np.sum(counts)
    full = [1] * len(counts)
    subactions = [text.split("while")[1] + " [" + str(round(counts[i] * 100, 2)) + "%]" for i, text in enumerate(label_features[action_class]['texts'][0])]
    
    height = 0.95
    index = np.arange(len(counts))
    fig, ax = plt.subplots(figsize =(10, 4))
    p1 = plt.barh(index, full, height, color="white", edgecolor = "black")
    p2 = plt.barh(index, counts, height)
    ax.set_yticks(index)
    ax.set_yticklabels(subactions, ha="left")
    ax.tick_params(axis="y",direction="in", pad=-5, labelsize=12)
    plt.title(action_class, fontsize=25)
    ax.set_xlabel("Percentage of frames", fontsize=20)
    ax.set_ylabel("Sub-actions", fontsize=20)
    plt.tight_layout()
    plt.savefig(action_class + '.png', dpi=400)


if __name__ == '__main__':
    # datasets = ['hmdb51', 'ucf101', 'k400', 'k600', 'multithumos', 'thumos', 'activitynet', 
    #             'coin', 'youcook2', 'breakfast']
    # plot_subaction_distribution(datasets) #\\dataset = 'ucf101'
    
    dataset = "ucf101"
    num_frames = -1
    split = 1
    
    #action_classes = ["PoleVault", "Archery", "BoxingPunchingBag", "FrontCrawl", "JumpingJack", "FrisbeeCatch", "HandstandWalking"] 
    action_classes = ["HandstandWalking"] 
    
    labels_folder = f"./data/direct_prompting_gpt3.5/{dataset}"
    model_string = "openai/clip-vit-base-patch16"
    mode = 1
    text_type='subaction'
    
    label_features = extract_label_features(model_string, labels_folder, mode=mode, text_type=text_type, num_sub_actions=0)
    
    frame_features_folder = f"./data/frame_features/openai_clip_vit_base_patch16/{dataset}"

    for action_class in action_classes:
        test_videos = [line.rstrip() for line in open(f"/home/c3-0/datasets/UCF101/testlist0{split}.txt", 'r').readlines() if action_class in line]
        visualize_subaction_assignment(action_class, frame_features_folder, label_features, test_videos, num_frames=num_frames)

            
    