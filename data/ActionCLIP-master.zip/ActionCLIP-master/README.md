# ActionCLIP
Code to train an action recognition model using CLIP features.

# Tracks
1. Improve zero-shot action classification using subactions
2. Subaction allow us to do ZS TAL
3. Subactions Unlock long video understanding
4. Subactions help finetuning generalize better

# TODO
0. Improve fine-tuning [P] []
1. Evaluate ViFi CLIP softmax training on UCF-101 [P]
2. Zero-shot evaluation using Open V-CLIP [P]
3. Fine-tuning the Open V-CLIP [P]
4. Fine-tuned ViFi CLIP results on UCF101 and THUMOS [P] [x]
5. Temporal Action Localization improvement using sub-actions for post-processing [P] []
6. Results on COIN for Task Classification using sub-actions from GPT [P] []
7. Youcook2 zero-shot results [P]
8. Results on COIN for Task Classification using ground-truth taxonomy [P] []
9. ActivityNet sub-actions [R] [x]
10. Feature extraction ActivityNet [P] [x]
11. VIP-CLIP results [R] []
12. VITA-CLIP results [R] []
13. Kinetics600 subactions for novel classes [R] [x]
14. Frame to sub-action assignment and check for patterns [P/R] []
15. Filtering of sub-actions from different LLMs [P/R] []
16. Check which classes have improvement in UCF101 [P] []
17. Pseudo-labeling analysis [R] []
18. Combine outputs from LLMs for zero-shot on UCF101 [P] []
19. Waffle CLIP text [R]
20. UCF-101 all splits [P]
21. RareAct sub-actions and visual description [R]
22. GPT 4 for UCF-101 [R]

# Other Ideas
1. EZCLIP - ICLR 2023
2. Long video: COIN (task), YouCook2 (recipe), Sports1M (sport recognition)
3. Temporally aware graph classifier
4. Can we use diff llm subsections during training
    
